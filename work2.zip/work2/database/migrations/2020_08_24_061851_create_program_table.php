<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateprogramTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Program', function (Blueprint $table) {
            $table->increments('ID ', 80);
            $table->string('prg_name_th')->unsigned();
            $table->integer('prg_name_en')->unsigned();
            $table->float('prg_unit_count')->nullable();
            $table->float('prg_degree')->nullable();
            $table->integer('prg_edit_year')->nullable();
            $table->timestamps();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('Program');
    }
}
