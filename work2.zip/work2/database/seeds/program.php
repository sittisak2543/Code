<?php

use Illuminate\Database\Seeder;

class programTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('program')->insert(array(

            [
            
            'id' => 1,   
            'prg_name_th' => 'เทคโนโลยีสารสนเทศ',            
            'prg_name_en' => 'Information Technology',           
            'prg_unit_count' => 125,            
            'prg_degree' => 'ปริญญาตรี',           
            'prg_edit_year' => 2563,
            
            ],
                        
            ));           
    }
}