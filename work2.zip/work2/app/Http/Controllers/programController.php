<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\program;
use App\Category;

class programController extends Controller
{
    var $rp = 2;

    public function index() {
        $programs = program::paginate($this->rp);
        return view('program/index', compact('programs'));
    }
    public function edit($id = null) {
        $categories = Category::pluck('name', 'id')->prepend('เลือกรายการ', '');
        if($id) {
            $program = program::where('id', $id)->first();
            return view('program/edit')
                ->with('program', $program);
        } else {
            return view('program/add');

        }
    
    }
    public function update(Request $request) {
        $rules = array(


            'prg_name_th' => 'required',
            'prg_name_en' => 'required',
            'prg_unit_count' => 'numeric',
            'prg_degree' => 'required',
            'prg_edit_year' => 'numeric',
        );
        $messages = array(
            'required' => 'กรุณากรอกข้อมูล :attribute ให้ครบถ้วน',
            'numeric' => 'กรุณากรอกข้อมูล :attribute ให้เป็นตัวเลข',
        );
        $id = $request->input('id');
        $validator = Validator::make($request->all(), $rules, $messages);
        if ($validator->fails()) {
            return redirect('program/edit/'.$id)
                ->withErrors($validator)
                ->withInput();
        }
        $program = program::find($id);
        $program->prg_name_th = $request->input('prg_name_th');
        $program->prg_name_en = $request->input('prg_name_en');
        $program->prg_unit_count = $request->input('required');
        $program->prg_degree = $request->input('prg_degree');
        $program->prg_edit_year = $request->input('prg_edit_year');
        $program->save();
        return redirect('program')
            ->with('ok', true)
            ->with('msg', 'บันทึกข้อมูลเรียบร้อยแล้ว');
    
    }
    public function insert(Request $request) {
        $rules = array(
            'prg_name_th' => 'required',
            'prg_name_en' => 'required',
            'prg_unit_count' => 'numeric',
            'prg_degree' => 'required',
            'prg_edit_year' => 'numeric',
        );
        $messages = array(
            'required' => 'กรุณากรอกข้อมูล :attribute ให้ครบถ้วน',
            'numeric' => 'กรุณากรอกข้อมูล :attribute ให้เป็นตัวเลข',
        );
        $validator = Validator::make($request->all(), $rules, $messages);
        if ($validator->fails()) {
            return redirect('program/edit')
                ->withErrors($validator)
                ->withInput();
        }
        $program = new program();
        $program->prg_name_th = $request->input('prg_name_th');
        $program->prg_name_en = $request->input('prg_name_en');
        $program->prg_unit_count = $request->input('required');
        $program->prg_degree = $request->input('prg_degree');
        $program->prg_edit_year = $request->input('prg_edit_year');
        $program->save();
        return redirect('program')
            ->with('ok', true)
            ->with('msg', 'เพิ่มข้อมูลเรียบร้อยแล้ว');
    }
    

 
    public function search(Request $request) {
        $query = $request->input('q');
        if($query) {
            $program = program::where('name', 'like', '%'.$query.'%')
                ->orWhere('name', 'like', '%'.$query.'%')
                ->paginate($this->rp);


        } else {
            $program = program::paginate($this->rp);
        }
        return view('program/index', compact('program'));

    }

    public function remove($id) {
        program::find($id)->delete();
        return redirect('program')
            ->with('ok', true)
            ->with('msg', 'ลบข้อมูลสำเร็จ');
    }
    
    
    
    
}
