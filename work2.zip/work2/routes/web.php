<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/program', 'programController@index');
Route::post('/program/search', 'programController@search');
Route::get('/program/search', 'programController@search');
Route::get('/program/edit/{id?}', 'programController@edit');
Route::post('/program/update', 'programController@update');
Route::post('/program/insert', 'programController@insert');
Route::get('/program/remove/{id}', 'programController@remove');


