@extends("layouts.master")
@section('title') BikeShop | เพิ่มข้อมูลสินค้า @stop
@section('content')
<div class="panel panel-default">
    {!! Form::open(array('action' => 'ProgramController@insert', 'method'=>'post', 'enctype' => 'multipart/form-data')) !!}

    @if($errors->any())
    <div class="alert alert-danger">
        @foreach ($errors->all() as $error)<div>{{ $error }}</div>@endforeach
    </div>
    @endif

    <div class="panel-heading">
        <div class="panel-title"><h3>เพิ่มข้อมูลสินค้า</h3></div>
    </div>
    <div class="panel-body">
        <table>
            <tr>
                <td>{{ Form::label('ID', 'ชื่อสินค้า') }}</td>
                <td>{{ Form::text('ID', Request::old('ID'), ['class' => 'form-control']) }}</td>
            </tr>
            <tr>
                <td>{{ Form::label('category_id', 'ประเภทสินค้า') }}</td>
                <td>{{ Form::select('category_id', $categories, Request::old('category_id'), ['class' => 'form-control']) }}</td>
            </tr>
            <tr>
                <td>{{ Form::label('unit_price', 'ราคาสินค้า') }}</td>
                <td>{{ Form::text('unit_price', Request::old('unit_price'), ['class' => 'form-control']) }}</td>
            </tr>
            <tr>
                <td>{{ Form::label('cost_price', 'ราคาทุน') }}</td>
                <td>{{ Form::text('cost_price', Request::old('cost_price'), ['class' => 'form-control']) }}</td>
            </tr>
            <tr>
                <td>{{ Form::label('stock_qty', 'จำนวนคงเหลือ') }}</td>
                <td>{{ Form::text('stock_qty', Request::old('stock_qty'), ['class' => 'form-control']) }}</td>
            </tr>        
            <tr>
                <td>{{ Form::label('image', 'เลือกรูปภาพสินค้า') }}</td>
                <td>{{ Form::file('image') }}</td>
            </tr>
        </table>
    </div>
    <div class="panel-footer">
      <button type="reset" class="btn btn-danger">ยกเลิก</button>
      <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> บันทึก</button>
    </div>
    {!! Form::close() !!}
</div>


@stop
