
<?php $__env->startSection('title'); ?> BikeShop | รายการสินค้า <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<h1>รายการสินค้า</h1>
<ul class="breadcrumb">
    <li><a href="#">หน้าแรก </a>&nbsp;</li>
    <li class="active">รายการสินค้า</li>
</ul>
<div class="panel panel-default">
    <div class="panel-body">
        <a href="<?php echo e(URL::to('product/edit')); ?>" class="btn btn-success pull-right"><i class="fa fa-plus"></i> เพิ่มข้อมูล</a>
        <form action="<?php echo e(URL::to('product/search')); ?>" method="post" class="form-inline">
            <?php echo e(csrf_field()); ?>

            <input type="text" name="q" class="form-control" placeholder="พิมพ์ชื่อสินค้าเพื่อค้นหา">
            <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> ค้นหา</button>
        </form>


     
    </div>
    <table class="table table-bordered table-striped table-hover">
        <thead>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($p->img_path); ?></td>
                <td><?php echo e($p->name); ?></td>
                <td><?php echo e($p->category->name); ?></td>
                <td><?php echo e($p->unit_price); ?></td>
                <td><?php echo e($p->stock_qty); ?></td>
                <td>
                    <a href="<?php echo e(URL::to('product/edit/'.$p->id)); ?>" class="btn btn-info"><i class="fa fa-pencil"></i></a>
                    <a href="#" class="btn btn-danger btn-delete" id-delete="<?php echo e($p->id); ?>"><i class="fa fa-trash-o"></i> ลบ</a>
                </td>
                <script>
                    $('.btn-delete').on('click', function() {
                        if(confirm("คุณต้องการลบข้อมูลสินค้าหรือไม่?")) {
                            var url = "<?php echo e(URL::to('product/remove')); ?>" + '/' + $(this).attr('id-delete');
                            window.location.href = url;
                        }
                    });
                </script>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo e($products->links()); ?>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Desktop\work\work2\resources\views/product/index.blade.php ENDPATH**/ ?>