 

<?php $__env->startSection('title'); ?> BikeShop | รายการสินค้า <?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Desktop\work\gadgetpro\resources\views/welcome.blade.php ENDPATH**/ ?>